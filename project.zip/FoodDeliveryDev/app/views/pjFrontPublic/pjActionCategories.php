<?php
$index = $controller->_get->toString('index'); 
include_once dirname(__FILE__) . '/elements/categories.php';
?>