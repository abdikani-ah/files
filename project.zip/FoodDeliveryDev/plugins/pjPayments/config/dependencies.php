<?php
return array(
    'jquery' => '>=3.1.1',
    'jquery_ui' => '>=1.12.1',
);
?>